""" Class to handle items (alarm, power ups, beacon) """

import pygame as pg
import data.code.config as cfg


class Alarm:
    def __init__(self):
        self.starting_pos = (440, 340)
        self.image = pg.image.load('data/sprite/alarm.png')
        self.image = pg.transform.scale(self.image, (20, 20))
        self.color = cfg.RED
        self.total_turns = 0

    def draw(self, screen):
        pg.draw.rect(screen, self.color, pg.Rect(self.starting_pos, (20, 20)))
        screen.blit(self.image, self.starting_pos)

    def update(self):
        self.total_turns += 1
        if self.total_turns % 100 == 1:
            cfg.is_yard_time = not cfg.is_yard_time
            print("Yard Time")


class PowerUp:
    def __init__(self, starting_pos, color, index):
        self.starting_pos = starting_pos
        self.color = color
        self.index = index
        pawn_width = pawn_height = 20
        self.item_dimension = (pawn_width, pawn_height)
        self.rect = pg.Rect(self.starting_pos, self.item_dimension)
        self.name = f"PowerUp_{index}"
        self.is_killed = False

    def draw(self, screen):
        if not self.is_killed:
            pg.draw.rect(screen, self.color, self.rect)

    def kill(self):
        self.is_killed = True
        self.rect.update((-100, -100), self.item_dimension)


class Beacon:
    def __init__(self, beacon_1_pos, beacon_2_pos):
        self.beacon_1_pos = beacon_1_pos
        self.beacon_2_pos = beacon_2_pos
        self.off_color = cfg.BROWN
        self.on_color = cfg.RED
        self.current_color = self.off_color
        item_width = 60
        item_height = 20
        self.item_dimension = (item_width, item_height)

    def draw(self, screen):
        pg.draw.rect(screen, self.current_color, pg.Rect(self.beacon_1_pos, self.item_dimension))
        pg.draw.rect(screen, self.current_color, pg.Rect(self.beacon_2_pos, self.item_dimension))

    def update(self):
        if cfg.is_beacon_on:
            self.current_color = self.on_color
        else:
            self.current_color = self.off_color
        # Reset beacon
        cfg.is_beacon_on = False
