""" Class to handle grid lines """

import pygame as pg
import data.code.config as cfg


class GridLine:
    def __init__(self, width, height):
        self.starting_pos = [0, 0]
        self.grid_width = width
        self.grid_height = height

    def draw_gridline(self, screen):
        x0, y0 = self.starting_pos
        color = cfg.GREEN
        line_space = 20
        lines_per_grid = 5
        x_line_amount = int(self.grid_width / line_space)
        y_line_amount = int(self.grid_height / line_space)

        # Draw vertical lines
        for line in range(x_line_amount):
            x_pos = line * line_space
            if line % lines_per_grid == 0:
                pg.draw.line(screen, color, (x_pos, y0), (x_pos, self.grid_height), 2)
            else:
                pg.draw.line(screen, color, (x_pos, y0), (x_pos, self.grid_height), 1)

        # Draw horizontal lines
        for line in range(y_line_amount):
            y_pos = self.grid_height - (line * line_space)
            if line % lines_per_grid == 0:
                pg.draw.line(screen, color, (x0, y_pos), (self.grid_width, y_pos), 2)
            else:
                pg.draw.line(screen, color, (x0, y_pos), (self.grid_width, y_pos), 1)