""" Classes to handle pawns (prisoner, police goose, dog) """

import pygame as pg
import random

import data.code.config as cfg


class Pawn:
    def __init__(self, starting_pos, color, index):
        self.STARTING_POS = starting_pos
        self.dynamic_pos = list(starting_pos)
        self.color = color
        self.index = index
        self.speed = 20
        pawn_width = pawn_height = 20
        self.pawn_dimension = (pawn_width, pawn_height)
        self.rect = pg.Rect(starting_pos, self.pawn_dimension)
        self.chary = pg.font.Font('data/font/chary.ttf', 20)

    def draw(self, screen):
        pg.draw.rect(screen, self.color, self.rect)
        text_obj = self.chary.render(self.index, True, cfg.CREAM)
        screen.blit(text_obj, self.dynamic_pos)


class Prisoner(Pawn):
    def __init__(self, starting_pos, color, index):
        super().__init__(starting_pos, color, index)
        self.name = f'Prisoner_{self.index}'

        # Generate random starting direction
        self.x_speed = self.y_speed = 0
        self.generate_rand_direction()

        # Generate hitbox
        self.hitbox_dimension = (40, 40)
        self.prisoner_hitbox = pg.Rect((starting_pos[0] - 10, starting_pos[1] - 10), self.hitbox_dimension)

        # misc
        self.collisions = [False] * 9
        self.is_powered_up = False
        self.is_killed = False

    def draw(self, screen):
        if not self.is_killed:
            pg.draw.rect(screen, self.color, self.rect)
            if self.is_powered_up:
                text_obj = self.chary.render(self.index, True, cfg.LIME)
            else:
                text_obj = self.chary.render(self.index, True, cfg.CREAM)
            screen.blit(text_obj, self.dynamic_pos)

    def update(self):
        if self.is_killed:
            self.dynamic_pos = [0, 0]
        else:
            collisions = self.collisions

            # Side collisions
            if collisions[1]:
                self.y_speed = self.speed

            elif collisions[3]:
                self.x_speed = self.speed

            elif collisions[5]:
                self.x_speed = -self.speed

            elif collisions[7]:
                self.y_speed = -self.speed

            # Outer corner collisions
            def single_true(iterable):
                i = iter(iterable)
                return any(i) and not any(i)

            if single_true(collisions):
                if collisions[0] and self.x_speed < 0 and self.y_speed < 0:
                    self.x_speed = self.speed
                    self.y_speed = self.speed

                elif collisions[2] and self.x_speed > 0 and self.y_speed < 0:
                    self.x_speed = -self.speed
                    self.y_speed = self.speed

                elif collisions[6] and self.x_speed < 0 and self.y_speed > 0:
                    self.x_speed = self.speed
                    self.y_speed = -self.speed

                elif collisions[8] and self.x_speed > 0 and self.y_speed > 0:
                    self.x_speed = -self.speed
                    self.y_speed = -self.speed

            # Inner corner collisions
            if collisions[0] and collisions[1] and collisions[2] and collisions[3] and collisions[6]:
                self.x_speed = self.speed
                self.y_speed = self.speed
            elif collisions[0] and collisions[1] and collisions[2] and collisions[5] and collisions[8]:
                self.x_speed = -self.speed
                self.y_speed = self.speed
            elif collisions[2] and collisions[5] and collisions[8] and collisions[7] and collisions[6]:
                self.x_speed = -self.speed
                self.y_speed = -self.speed
            elif collisions[0] and collisions[3] and collisions[6] and collisions[7] and collisions[8]:
                self.x_speed = self.speed
                self.y_speed = -self.speed

            # Sandwich position collision
            if collisions[1] and collisions[7]:
                self.y_speed = 0
            elif collisions[3] and collisions[5]:
                self.x_speed = 0

            # Center collision
            if collisions[4]:
                pass

            # Check if prisoner is not moving/moving in a straight line and correct it
            if True not in collisions:
                if self.x_speed == 0:
                    self.generate_rand_direction(pick_direction='x')
                elif self.y_speed == 0:
                    self.generate_rand_direction(pick_direction='y')
                elif self.x_speed == 0 and self.y_speed == 0:
                    self.generate_rand_direction()

            # X movement
            self.dynamic_pos[0] += self.x_speed
            # Y movement
            self.dynamic_pos[1] += self.y_speed

        # Update rect
        self.rect.update(self.dynamic_pos, self.pawn_dimension)
        self.prisoner_hitbox.update((self.dynamic_pos[0] - 10, self.dynamic_pos[1] - 10), self.hitbox_dimension)

        # Reset total collision
        self.collisions = [False] * 9

    def collision_detection(self, obj):
        """
        collision points on a rect:
        0--1--2
        3--4--5
        6--7--8
        """
        if "Dog" in obj.name:
            rect = obj.hitbox_rect
        else:
            rect = obj.rect
        collisions = [False] * 9
        collisions[0] = rect.collidepoint(self.prisoner_hitbox.topleft)
        collisions[1] = rect.collidepoint(self.prisoner_hitbox.midtop)
        collisions[2] = rect.collidepoint(self.prisoner_hitbox.topright)

        collisions[3] = rect.collidepoint(self.prisoner_hitbox.midleft)
        collisions[4] = rect.collidepoint(self.prisoner_hitbox.center)
        collisions[5] = rect.collidepoint(self.prisoner_hitbox.midright)

        collisions[6] = rect.collidepoint(self.prisoner_hitbox.bottomleft)
        collisions[7] = rect.collidepoint(self.prisoner_hitbox.midbottom)
        collisions[8] = rect.collidepoint(self.prisoner_hitbox.bottomright)

        self.calculate_total_collision(collisions)

    def collision_detection_simple(self, obj):
        if self.prisoner_hitbox.colliderect(obj.rect):
            if "PoliceGoose" in obj.name:
                print(f"{obj.name} has beaten {self.name}")
                self.dynamic_pos = self.generate_rand_start_pos()
            elif "ExitZone" in obj.name:
                if not self.is_killed:
                    print(f"{self.name} won!")
                    self.x_speed = 0
                    self.y_speed = 0
                    self.kill()
            elif "PowerUp" in obj.name:
                print(f"{self.name} picked up {obj.name}!")
                self.is_powered_up = True
                obj.kill()
            elif "Box" in obj.name:
                if 0 <= int(obj.index) <= 5:
                    print(f"{self.name} has been shocked brutally!")
                    cfg.is_beacon_on = True

    def calculate_total_collision(self, input_collision):
        total_collision = [False] * 9
        for i, collision in enumerate(self.collisions):
            if collision or input_collision[i]:
                total_collision[i] = True
            else:
                total_collision[i] = False
        self.collisions = total_collision

    def kill(self):
        self.is_killed = True
        self.rect.update((0, 0), self.pawn_dimension)

    def generate_rand_direction(self, pick_direction='both'):
        if pick_direction == 'x':
            if random.randint(0, 1):
                self.x_speed = self.speed
            else:
                self.x_speed = -self.speed
        elif pick_direction == 'y':
            if random.randint(0, 1):
                self.y_speed = self.speed
            else:
                self.y_speed = -self.speed
        else:
            if random.randint(0, 1):
                self.x_speed = self.speed
            else:
                self.x_speed = -self.speed
            if random.randint(0, 1):
                self.y_speed = self.speed
            else:
                self.y_speed = -self.speed

    @staticmethod
    def generate_rand_start_pos():
        if random.randint(0, 1):
            rand_x = random.randrange(24, 38, 2)
            rand_y = random.randrange(24, 46, 2)
        else:
            rand_x = random.randrange(52, 64, 2)
            rand_y = random.randrange(24, 46, 2)
        return [rand_x * 10, rand_y * 10]


class PoliceGoose(Pawn):
    def __init__(self, starting_pos, color, index):
        super().__init__(starting_pos, color, index)
        self.name = f'PoliceGoose_{self.index}'
        self.image = pg.image.load('data/sprite/police_goose.png')
        self.image = pg.transform.scale(self.image, (20, 20))
        self.is_evacuating = False

    def draw(self, screen):
        pg.draw.rect(screen, self.color, self.rect)
        screen.blit(self.image, self.dynamic_pos)
        ## DEBUG: draw police goose index
        # text_obj = self.chary.render(self.index, True, cfg.CREAM)
        # screen.blit(text_obj, self.dynamic_pos)

    def update(self):
        if cfg.is_evacuating or cfg.is_yard_time:
            self.is_evacuating = True
            if self.index == '0':
                self.dynamic_pos = [120, 120]
            elif self.index == '1':
                self.dynamic_pos = [760, 560]
        else:
            if self.is_evacuating:
                self.dynamic_pos = list(self.STARTING_POS)
                self.is_evacuating = False
            if self.dynamic_pos[0] <= 400:
                self.speed = abs(self.speed)
            elif self.dynamic_pos[0] >= 480:
                self.speed = -abs(self.speed)
            self.dynamic_pos[0] += self.speed
        # Update rect
        self.rect.update(self.dynamic_pos, self.pawn_dimension)


class Dog(Pawn):
    def __init__(self, starting_pos, color, index):
        super().__init__(starting_pos, color, index)
        self.is_horizontal = False
        self.name = f'Dog_{index}'
        self.hitbox_dimension = (140, 60)
        self.x_speed = self.y_speed = 0
        self.hitbox_rect = pg.Rect((starting_pos[0] - 20, starting_pos[1] - 20), self.hitbox_dimension)
        self.hitbox_pos = (0, 0)
        self.image = pg.image.load('data/sprite/dog.png')
        self.image = pg.transform.scale(self.image, (20, 20))

    def draw(self, screen):
        # pg.draw.rect(screen, 'white', self.hitbox_rect)  # DEBUG: draw dog hitbox
        pg.draw.rect(screen, self.color, self.rect)
        screen.blit(self.image, self.dynamic_pos)

    def update(self):
        if tuple(self.dynamic_pos) == self.STARTING_POS:
            self.is_horizontal = not self.is_horizontal
        if self.is_horizontal:
            self.move_horizontal()
            self.y_speed = 0
        else:
            self.move_vertical()
            self.x_speed = 0
        self.move_hitbox()
        # Update rect
        self.rect.update(self.dynamic_pos, self.pawn_dimension)

    def move_horizontal(self):
        if self.dynamic_pos[0] <= 160:
            self.x_speed = abs(self.speed)
        elif self.dynamic_pos[0] >= 720:
            self.x_speed = -abs(self.speed)
        self.dynamic_pos[0] += self.x_speed

    def move_vertical(self):
        if self.dynamic_pos[1] <= 160:
            self.y_speed = abs(self.speed)
        elif self.dynamic_pos[1] >= 520:
            self.y_speed = -abs(self.speed)
        self.dynamic_pos[1] += self.y_speed

    def move_hitbox(self):
        temp_dimension = ()
        if self.x_speed > 0:
            self.hitbox_pos = (self.dynamic_pos[0] - 20, self.dynamic_pos[1] - 20)
            temp_dimension = self.hitbox_dimension
        elif self.x_speed < 0:
            self.hitbox_pos = (self.dynamic_pos[0] - 100, self.dynamic_pos[1] - 20)
            temp_dimension = self.hitbox_dimension
        elif self.y_speed > 0:
            self.hitbox_pos = (self.dynamic_pos[0] - 20, self.dynamic_pos[1] - 20)
            temp_dimension = (self.hitbox_dimension[1], self.hitbox_dimension[0])
        elif self.y_speed < 0:
            self.hitbox_pos = (self.dynamic_pos[0] - 20, self.dynamic_pos[1] - 100)
            temp_dimension = (self.hitbox_dimension[1], self.hitbox_dimension[0])

        self.hitbox_rect.update(self.hitbox_pos, temp_dimension)
