""" Class to handle boxes """

import pygame as pg
import data.code.config as cfg


class Box:
    def __init__(self, starting_pos, dimensions, color, index):
        self.starting_pos = starting_pos
        self.evacuated_pos = (0, -20)
        self.color = color
        box_width, box_height = dimensions
        self.box_dimension = (box_width, box_height)
        self.rect = pg.Rect(starting_pos, self.box_dimension)
        self.index = index
        self.name = f"Box_{index}"
        self.chary = pg.font.Font('data/font/chary.ttf', 20)

    def draw(self, screen):
        pg.draw.rect(screen, self.color, self.rect)
        
class Gate(Box):
    def update(self):
        if cfg.is_evacuating:
            self.rect.update(self.evacuated_pos, self.box_dimension)
        else:
            self.rect.update(self.starting_pos, self.box_dimension)


class ExitZone(Box):
    def __init__(self, starting_pos, dimensions, color, index):
        super().__init__(starting_pos, dimensions, color, index)
        self.name = f"ExitZone_{index}"

    def draw(self, screen):
        pass
