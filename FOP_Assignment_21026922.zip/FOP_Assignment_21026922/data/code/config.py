""" Config File for Global Variables """

import pygame

# Screen Size
screen_width = 1200
screen_height = 700

# Color
BLUE = pygame.Color("#6db5ba")
LIME = pygame.Color("#76aa3a")
GREEN = pygame.Color("#26544c")
CREAM = pygame.Color("#fbfdbe")
RED = pygame.Color("#d23c4f")
BLACK = pygame.Color("#2b1328")
BROWN = pygame.Color("#753d38")
ORANGE = pygame.Color("#efad5f")
WHITE = pygame.Color("#ffffff")

# Variables
is_beacon_on = False
is_evacuating = False
is_yard_time = True
