"""
Main Program File
"""

import sys
from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'


import pygame as pg
import data.code.config as cfg
import data.code.pawn as pawn
import data.code.item as item
import data.code.box as box
from data.code.gridline import GridLine


# Initialize pygame
pg.init()
clock = pg.time.Clock()
MOVEEVENT = pg.USEREVENT + 1
pg.time.set_timer(MOVEEVENT, 100)

# Initiate screen
cfg.screen_width = 900
cfg.screen_height = 700
screen_resolution = (cfg.screen_width, cfg.screen_height)
screen = pg.display.set_mode((cfg.screen_width, cfg.screen_height))

# Set caption, icon
pg.display.set_caption("FOP Assignment")
icon = pg.image.load('data/sprite/police_goose.png')
icon = pg.transform.scale(icon, (20, 20))
pg.display.set_icon(icon)


class Program:
    def __init__(self):
        self.gridline = GridLine(cfg.screen_width, cfg.screen_height)
        self.boxes = [
            # Box 1
            box.Box((100, 100), (700, 20), cfg.BLACK, '0'),
            box.Box((100, 580), (700, 20), cfg.BLACK, '1'),
            box.Box((100, 100), (20, 200), cfg.BLACK, '2'),
            box.Box((100, 400), (20, 200), cfg.BLACK, '3'),
            box.Box((780, 100), (20, 200), cfg.BLACK, '4'),
            box.Box((780, 400), (20, 200), cfg.BLACK, '5'),
            # Box 2
            box.Box((200, 200), (200, 20), cfg.BLACK, '6'),
            box.Box((200, 480), (200, 20), cfg.BLACK, '7'),
            box.Box((500, 200), (200, 20), cfg.BLACK, '8'),
            box.Box((500, 480), (200, 20), cfg.BLACK, '9'),
            box.Box((200, 200), (20, 300), cfg.BLACK, '10'),
            box.Box((680, 200), (20, 300), cfg.BLACK, '11')
        ]
        self.gates = [
            box.Gate((400, 200), (100, 20), cfg.BROWN, '0'),
            box.Gate((400, 480), (100, 20), cfg.BROWN, '1')
        ]
        self.exit_zone = [
            box.ExitZone((60, 300), (40, 100), cfg.LIME, '0'),
            box.ExitZone((800, 300), (40, 100), cfg.LIME, '1')
        ]
        self.chary = pg.font.Font('data/font/chary.ttf', 20)

        # Initiate random prisoners starting locations
        self.prisoners = []
        for i in range(8):
            self.prisoners.append(pawn.Prisoner(pawn.Prisoner.generate_rand_start_pos(), cfg.ORANGE, f'{i}'))

        # Initiate police geese and dogs object list
        self.police_geese = [
            pawn.PoliceGoose((480, 180), cfg.BLUE, '0'),
            pawn.PoliceGoose((400, 500), cfg.BLUE, '1')
        ]
        self.dogs = [
            pawn.Dog((160, 520), cfg.RED, '0'),
            pawn.Dog((720, 160), cfg.RED, '1')
        ]
        # Initiate items
        self.alarm = item.Alarm()
        self.power_ups = [
            item.PowerUp((440, 280), cfg.LIME, '0'),
            item.PowerUp((440, 400), cfg.LIME, '1')
        ]
        self.beacon = item.Beacon((420, 120), (420, 560))

        # misc
        self.last_time = 0
        self.is_gridline_on = True
        self.is_playing = False

    def run(self):
        while True:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if pg.key.get_pressed()[pg.K_d]:
                        self.is_gridline_on = not self.is_gridline_on
                    if pg.key.get_pressed()[pg.K_RIGHT]:
                        self.update_all()
                    if pg.key.get_pressed()[pg.K_SPACE]:
                        self.is_playing = not self.is_playing
                    if pg.key.get_pressed()[pg.K_e]:
                        cfg.is_evacuating = not cfg.is_evacuating
                # Executes every 100 milliseconds
                if event.type == MOVEEVENT and self.is_playing:
                    self.update_all()

            self.draw_debug()
            self.draw_all()

            # Updates
            pg.display.flip()
            screen.fill(cfg.CREAM)

    def draw_all(self):
        # Draw list of objects
        def draw_object_list(object_list):
            for i, obj_ in enumerate(object_list):
                obj_.draw(screen)

        # Boxes
        draw_object_list(self.boxes)
        draw_object_list(self.gates)
        draw_object_list(self.exit_zone)

        # Pawns
        draw_object_list(self.prisoners)
        draw_object_list(self.police_geese)
        draw_object_list(self.dogs)

        # Items
        self.alarm.draw(screen)
        self.beacon.draw(screen)
        draw_object_list(self.power_ups)

        # Instruction
        self.draw_instructions()

    def update_all(self):
        # Collision detection
        for j, prisoner in enumerate(self.prisoners):
            for k, obj in enumerate(self.police_geese):
                prisoner.collision_detection_simple(obj)
            for k, obj in enumerate(self.exit_zone):
                prisoner.collision_detection_simple(obj)
            for k, obj in enumerate(self.boxes):
                prisoner.collision_detection(obj)
                prisoner.collision_detection_simple(obj)
            for k, obj in enumerate(self.power_ups):
                prisoner.collision_detection_simple(obj)
            for k, obj in enumerate(self.dogs):
                prisoner.collision_detection(obj)
            if not prisoner.is_powered_up:
                for k, obj in enumerate(self.gates):
                    prisoner.collision_detection(obj)

        # Update list of objects
        def update_object_list(object_list):
            for i, obj_ in enumerate(object_list):
                obj_.update()

        # Pawns
        update_object_list(self.prisoners)
        update_object_list(self.police_geese)
        update_object_list(self.dogs)

        # Items
        self.beacon.update()
        self.alarm.update()

        # Gates
        update_object_list(self.gates)

    def draw_debug(self):
        # Draw
        if self.is_gridline_on:
            self.gridline.draw_gridline(screen)
            # Debug coordinate
            mouse_pos = pg.mouse.get_pos()
            text_obj = self.chary.render(f"{mouse_pos}", True, cfg.LIME)
            screen.blit(text_obj, mouse_pos)

    def draw_instructions(self):
        texts = [self.chary.render("Instructions:", True, cfg.BLACK),
                 self.chary.render("Press RIGHT ARROW to play once", True, cfg.BLACK),
                 self.chary.render("Press SPACE to toggle continuous play", True, cfg.BLACK),
                 self.chary.render("Press E to toggle evacuation state", True, cfg.BLACK),
                 self.chary.render("Press D to toggle debug view", True, cfg.BLACK)]

        for i, text in enumerate(texts):
            screen.blit(text, (100, 600 + i * 20))


if __name__ == '__main__':
    program = Program()
    program.run()
